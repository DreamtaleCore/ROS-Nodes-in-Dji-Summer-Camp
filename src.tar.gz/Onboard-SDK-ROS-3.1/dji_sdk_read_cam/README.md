##DJI Onboard SDK ROS Package for Video Decoding on Manifold

Documentation has been moved to the developer website. 

First time users of OnboardSDK, please refer to the below link:
https://developer.dji.com/onboard-sdk/documentation/quick-start/index.html

ROS Readcam package documentation:
https://developer.dji.com/onboard-sdk/documentation/github-platform-docs/ROS_Example/ros_video_decoding_package.html